package me.example.invviewer;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class InvViewer extends JavaPlugin implements Listener {

    /** ตัวระบุว่าเป็นหน้าต่างของปลั๊กอินนี้ (ใช้กันการแก้ไขของ) */
    private static class ViewHolder implements InventoryHolder {
        private Inventory inventory;

        @Override
        public @NotNull Inventory getInventory() {
            return inventory;
        }
    }

    @Override
    public void onEnable() {
        Bukkit.getPluginManager().registerEvents(this, this);
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command,
                             @NotNull String label, @NotNull String[] args) {
        if (!(sender instanceof Player viewer)) {
            sender.sendMessage(Component.text("คำสั่งนี้ใช้ได้เฉพาะในเกม", NamedTextColor.RED));
            return true;
        }
        if (!viewer.hasPermission("invviewer.use")) {
            viewer.sendMessage(Component.text("คุณไม่มีสิทธิ์ใช้คำสั่งนี้", NamedTextColor.RED));
            return true;
        }
        if (args.length != 1) {
            viewer.sendMessage(Component.text("ใช้: /inv <ชื่อผู้เล่น>", NamedTextColor.YELLOW));
            return true;
        }

        Player target = Bukkit.getPlayerExact(args[0]);
        if (target == null) {
            viewer.sendMessage(Component.text("ไม่พบผู้เล่น '" + args[0] + "' (ต้องออนไลน์อยู่)", NamedTextColor.RED));
            return true;
        }

        viewer.openInventory(buildView(target));
        return true;
    }

    @Override
    public List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command,
                                      @NotNull String alias, @NotNull String[] args) {
        List<String> result = new ArrayList<>();
        if (args.length == 1) {
            String prefix = args[0].toLowerCase(Locale.ROOT);
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (p.getName().toLowerCase(Locale.ROOT).startsWith(prefix)) {
                    result.add(p.getName());
                }
            }
        }
        return result;
    }

    /**
     * เลย์เอาต์ 54 ช่อง:
     * แถว 1-3 = ช่องเก็บของ, แถว 4 = hotbar, แถว 5 = ช่องว่าง, แถว 6 = หมวก/เสื้อ/กางเกง/รองเท้า/มือรอง
     */
    private Inventory buildView(Player target) {
        ViewHolder holder = new ViewHolder();
        Inventory inv = Bukkit.createInventory(holder, 54,
                Component.text("กระเป๋าของ " + target.getName()));
        holder.inventory = inv;

        PlayerInventory pi = target.getInventory();

        // ช่องเก็บของ (slot 9-35) -> 0-26
        for (int i = 9; i < 36; i++) {
            inv.setItem(i - 9, pi.getItem(i));
        }
        // hotbar (slot 0-8) -> 27-35
        for (int i = 0; i < 9; i++) {
            inv.setItem(27 + i, pi.getItem(i));
        }
        // แถวคั่น
        ItemStack filler = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        ItemMeta meta = filler.getItemMeta();
        meta.displayName(Component.text(" "));
        filler.setItemMeta(meta);
        for (int i = 36; i < 54; i++) {
            inv.setItem(i, filler);
        }
        // เกราะ + มือรอง
        inv.setItem(45, pi.getHelmet());
        inv.setItem(46, pi.getChestplate());
        inv.setItem(47, pi.getLeggings());
        inv.setItem(48, pi.getBoots());
        inv.setItem(50, pi.getItemInOffHand());

        return inv;
    }

    // ---- ดูได้อย่างเดียว ห้ามหยิบ/ย้ายของ ----

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof ViewHolder) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof ViewHolder) {
            e.setCancelled(true);
        }
    }
}
